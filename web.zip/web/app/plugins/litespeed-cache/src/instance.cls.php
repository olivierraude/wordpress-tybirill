<?php
/**
 * The abstract instance
 *
 * @since      	3.0
 */
namespace LiteSpeed;

defined('WPINC') || exit();

abstract class Instance extends Root
{
}
