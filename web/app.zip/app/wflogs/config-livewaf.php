<?php exit('Access denied'); __halt_compiler(); ?>
******************************************************************
This file is used by the Wordfence Web Application Firewall. Read 
more at https://docs.wordfence.com/en/Web_Application_Firewall_FAQ
******************************************************************
a:2:{s:4:"cron";a:4:{i:0;O:42:"wfWAFCronFetchCookieRedactionPatternsEvent":1:{s:11:" * fireTime";i:1706215146;}i:1;O:24:"wfWAFCronFetchRulesEvent":1:{s:11:" * fireTime";i:1706215146;}i:2;O:25:"wfWAFCronFetchIPListEvent":1:{s:11:" * fireTime";i:1706132537;}i:3;O:36:"wfWAFCronFetchBlacklistPrefixesEvent":1:{s:11:" * fireTime";i:1706125579;}}s:20:"whitelistedURLParams";N;}