<?php get_header() ?>

<section>

  <div class="container logo">
    <div class="container badrequest">
      <h1>
        <img src="./app/uploads/2023/10/logo-404.png" class="" alt="Ferme Ty Birill">
      </h1>
      <a href="http://localhost:3000/TyBirill/web/"><span>&#8592;</span> Retour vers l'accueil</a>
    </div>
  </div>

</section>

<?php get_footer() ?>